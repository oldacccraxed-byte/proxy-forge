# Proxy Forge 2.0 (Android Studio project)

A native Kotlin + Jetpack Compose starter app with a red/black theme.

## Build
1. Open this folder in Android Studio (Giraffe or newer).
2. Let Gradle sync.
3. Connect an Android device or start an emulator.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).

The APK will be under `app/build/outputs/apk/debug/`.

## Features
- Offline generation; no network calls.
- Template format with `{SID}` placeholder.
- Sequential, random, and fixed SID modes.
- Optional SID prefix.
- 1–100,000 generated lines.
- Preview first 20 entries.
- Save TXT through Android's document picker.
- Optional file splitting; tap Save Part repeatedly to export each chunk.

## Notes
Replace the template with your own authorized proxy format. This app only formats text locally; it does not test, validate, or connect to proxies.
